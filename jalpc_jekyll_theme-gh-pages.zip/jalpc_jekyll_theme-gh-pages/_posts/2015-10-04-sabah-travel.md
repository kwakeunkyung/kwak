---
layout: post
title:  "我们在沙巴"
desc: "沙巴之旅"
keywords: "Malaysia,马来西亚,旅行,沙巴,Sabah"
date:   2015-10-04
categories: [Life]
tags: [Life]
icon: fa-bookmark-o
---

## 沙巴美景

#### 沙巴附近的海域

![Sabah]({{ site.img_path }}/Malaysia_Sabah/1.jpg)

海水变成绿色的，在香蕉船上拍的照片。

![Sabah]({{ site.img_path }}/Malaysia_Sabah/2.jpg)

去红树林看猴子，远处的海滩。

![Sabah]({{ site.img_path }}/Malaysia_Sabah/7.jpg)

在沙巴附近小岛的沙滩游泳拍照。

![Sabah]({{ site.img_path }}/Malaysia_Sabah/3.jpg)

沙巴清真寺一游

![Sabah]({{ site.img_path }}/Malaysia_Sabah/6.jpg)

其实我也看不懂书的内容

![Sabah]({{ site.img_path }}/Malaysia_Sabah/5.jpg)

哈哈

![Sabah]({{ site.img_path }}/Malaysia_Sabah/4.jpg)
